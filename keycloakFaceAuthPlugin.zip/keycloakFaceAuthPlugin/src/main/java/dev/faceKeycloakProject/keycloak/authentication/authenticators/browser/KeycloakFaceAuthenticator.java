package dev.faceKeycloakProject.keycloak.authentication.authenticators.browser;

import org.apache.commons.io.IOExceptionWithCause;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.keycloak.authentication.AuthenticationFlowContext;
import org.keycloak.authentication.Authenticator;
import org.keycloak.models.KeycloakSession;
import org.keycloak.models.RealmModel;
import org.keycloak.models.UserModel;
import org.keycloak.authentication.AuthenticationFlowError;
import org.jboss.logging.Logger;


import jakarta.ws.rs.core.MultivaluedMap;
import jakarta.ws.rs.core.Response;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Base64;


public class KeycloakFaceAuthenticator implements Authenticator{
    private static Logger logger = Logger.getLogger(KeycloakFaceAuthenticator.class);

    protected Boolean validateFace(AuthenticationFlowContext context) throws ClientProtocolException, IOException {
        System.out.println("rwtf");
        MultivaluedMap<String, String> formData = context.getHttpRequest().getDecodedFormParameters();
        String imageData = formData.getFirst("imageCanvas");
        System.out.println("imageData ==================>" + imageData);
        imageData = imageData.split(",")[1];
        byte[] decodedImage = null;
        try {
            decodedImage = Base64.getDecoder().decode(imageData.getBytes("UTF-8"));
        } catch (UnsupportedEncodingException e1) {
            e1.printStackTrace();
        }
        try (CloseableHttpClient client = HttpClientBuilder.create().build()) {
            
            final String uriBase ="http://localhost:9000/detect";
             
            URIBuilder builder = new URIBuilder(uriBase);
            URI uri = builder.build();
            HttpPost request = new HttpPost(uri);
            
            request.setHeader("Content-Type", "application/octet-stream");
             
            ByteArrayEntity body = new ByteArrayEntity(decodedImage);
            request.setEntity(body);
 
            HttpResponse response = client.execute(request);
            HttpEntity entity = response.getEntity();
            
            if (entity != null)
            {
                // Format and display the JSON response.
                System.out.println("REST Response:\n");
                String jsonString = EntityUtils.toString(entity).trim();
                JSONObject jsonObject = new JSONObject(jsonString);
                String spoofResult = jsonObject.getString("spoofResult");
                int facesDetected = jsonObject.getInt("facesDetected");

                if ("real".equals(spoofResult) && facesDetected == 1) {
                    System.out.println("The spoofResult is real and facesDetected is 1.");

                    URIBuilder builderVerify = new URIBuilder("http://localhost:9000/recognize");
                    URI uriVerify = builderVerify.build();
                    HttpPost requestVerify = new HttpPost(uriVerify);
                    requestVerify.setHeader("Content-Type", "application/octet-stream");
                    requestVerify.setEntity(body);
                    HttpResponse responseVerify = client.execute(request);
                    HttpEntity entityVerify = responseVerify.getEntity();
                    if (entityVerify != null) {
                        String jsonStringVerify = EntityUtils.toString(entityVerify).trim();
                        JSONObject jsonObjectVerify = new JSONObject(jsonStringVerify);
                        String message=jsonObjectVerify.getString("message");
                        if("Face Verify".equals(message)){
                            String entityName = jsonObjectVerify.getJSONArray("results").getJSONArray(0).getJSONObject(0).getJSONObject("entity").getString("name");
                            System.out.println("Hello "+ entityName);
                            return true;
                        }
                        else{
                            return false;
                        }
                    }
                } else if(facesDetected >1){
                    System.out.println("Multiple faces in the image");
                    throw new Error("Multiple faces in the image");
                }
                else if("fake".equals(spoofResult)){
                    System.out.println("Spoof Detected");
                    throw new Error("Spoof Detected");
                }
                else{
                    System.out.println(jsonString);
                }
            }
        } catch (IOExceptionWithCause | URISyntaxException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return false;
        }
        return false;
    }

    // public static final FaceAuthenticator SINGLETON = new FaceAuthenticator();
    @Override
    public void close() {
        // TODO Auto-generated method stub
    }

    @Override
    public void action(AuthenticationFlowContext context) {
        System.out.println("action clled.... context = " + context);
        logger.info("action called ... context = " + context);
        Response challenge = null;

        logger.info(context.getUser());
        try {
            if(validateFace(context)) {
                System.out.print("Validate face called");
                context.success();
            } else {
                challenge = context.form()
                        .setInfo("Cannot recognize user")
                        .createForm("face-validation.ftl");
                context.failureChallenge(AuthenticationFlowError.INVALID_USER, challenge);
            }
        } catch (ClientProtocolException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    @Override
    public void authenticate(AuthenticationFlowContext context) {
        System.out.println("I am here..");
        logger.debug("authenticate called ... context = " + context);
        System.out.println(context);
        Response challenge = context.form().createForm("face-validation.ftl");
        System.out.println(challenge);
        context.challenge(challenge);
        System.out.println("Passed challenge");
    }

    @Override
    public boolean configuredFor(KeycloakSession session, RealmModel realm, UserModel user) {
        System.out.println("Config yo...");
        System.out.println(user);
        logger.debug("configuredFor called ... session=" + session + ", realm=" + realm + ", user=" + user);
        return true;
    }

    @Override
    public boolean requiresUser() {
        System.out.println("requiresUser");
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public void setRequiredActions(KeycloakSession session, RealmModel realm, UserModel user) {
        System.out.println("lol");
        // TODO Auto-generated method stub
    }
}

